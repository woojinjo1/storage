@echo off
setlocal
set /p com_port=QDLoader Com Port : 
QSaharaServer.exe -p \\.\COM%com_port% -s 13:prog_firehose_sdx55.mbn
fh_loader.exe --port=\\.\COM%com_port% --sendxml=erase_efs2.xml --search_path=./ --noprompt --showpercentagecomplete --zlpawarehost=1 --memoryname=nand --loglevel=1
pause