::copy /y K:\src\gen12\nad\apps_proc\poky\build\tmp-glibc\work\armv7at2hf-neon-oe-linux-gnueabi\lge-update\git-r1\image\usr\bin\osu_agent .
::pause

adb wait-for-device shell "mount -o rw,remount /"
adb push osu_agent /usr/bin
adb shell "chmod 755 /usr/bin/osu_agent"
adb shell "/usr/bin/osu_agent"
pause

